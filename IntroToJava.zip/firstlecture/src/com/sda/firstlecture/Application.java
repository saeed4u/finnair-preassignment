package com.sda.firstlecture;


import java.util.Scanner;

public class Application {

	static int age = 10;

	static String name = "Saeed";

	static float money = 10.2F;
	static char c;


	public static void main(String[] args) {
		/*System.out.println(args[0]);
		 *//*
		double money = 10.22F;
		int year = 2019;
		System.out.print(age);
		System.out.println();
		System.out.println();
		System.out.printf("%X:%X:%X:%X",192,168,1,10);*//*

		 *//**
		 * Accept input from user.
		 * Check if input is 4 and then print yeaaaaah!
		 *//*
		 *//*Scanner input = new Scanner(System.in);
		int number = Integer.parseInt(input.nextLine());
		if (number == 4) {
			System.out.println("yeaaaaah!");
		} else if (number == 5) {
			System.out.println("yeaaaaah! number is 5");
		} else {
			System.out.println("Number is " + number);
		}

		switch (number) {
			case 4:
				System.out.println("yeaaaaah! from switch");
				break;
			case 5:
				System.out.println("yeaaaaah! number is 5 from switch");
				break;
			default:
				System.out.println("Number is from switch " + number);
		}*//*


		//loops
		*//*boolean a = true;
		while (a) {
			System.out.println("a == true");
			a = false;
		}

		for (int num = 5; num < 11; num++) {
			System.out.println(num);
		}
		int num = 4;
		do {
			System.out.println(num);
			num--;
		} while (num > 1);

		String aName = "Mario";
		for (int i = 0; i < aName.length(); i++) {

			System.out.println(aName.charAt(i));
			System.out.println("After break");
		}
*//*
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				System.out.print("*");
			}
			System.out.println();
		}

		//arrays

		int[] intArrays = {1, 2, 3, 4, 5, 6};

		for (int number : intArrays) {
			System.out.println(number);
		}

		int[] newArrays = new int[5];
		intArrays[0] = 4;
		System.out.println(intArrays[0]);

		//OOP

		Animal cat = new Animal("Cat", "Inhale", "Eat");

		cat.printType();
		System.out.println(Animal.name);
		cat.setEat();


		Animal dog = new Animal("Dog", "Inhale 1", "Eat 1");

		dog.printType();
		dog.setEat();

		System.out.println(new Date().getTime());
		System.out.println(System.currentTimeMillis());
*/

		/*
		 *Rectangle
		 */
		/*try {
			//printRectangleEdges();
			printSquare();
		} catch (RuntimeException ex) {
			System.out.println("There was an error, please try again");
			printSquare();
		}*/
		//fibonacciSeries();

		//System.out.println(fibonacciSeriesRecursion(4));
		/*Animal[] animals = createAnimals();
		for (int index = 0; index < animals.length; index++) {
			Animal animal = animals[index];
			System.out.println(animal);
		}*/

		int[] values = createIntArrays();
		int sum = 0;
		for (int value : values) {
			sum = sum + value;
		}
		//System.out.println(sum);

		//ask user for number
		int number = 5; //24
		System.out.println(calculateFactorial(number));
	}

	//take home - recursion
	private static int calculateFactorial(int number) {
		if(number == 0){
			return 1;
		}
		return number * calculateFactorial(number - 1);
	}

	private static int[] createIntArrays() {
		int[] values = new int[15];
		for (int index = 0; index < 15; index++) {
			values[index] = index + 1;
		}
		return values;
	}


	private static Animal[] createAnimals() {
		Animal[] animals = new Animal[5];
		for (int index = 0; index < 5; index++) {
			animals[index] = new Animal("Dog " + (index + 1), "Breathe " + index, "Eat " + index);
		}
		return animals;
	}


	private static void fibonacciSeries() {
		int first = 0;
		int second = 1;
		int sum = first + second;
		System.out.println(sum);
		for (int i = 1; i < 3; i++) {
			System.out.println(sum);
			first = second;
			second = sum;
			sum = first + second;
		}
	}

	private static void printSquare() {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Please enter rows ");
		int rows = scanner.nextInt();
		if (rows % 2 != 0) {
			System.out.println("Please enter an even number of rows");
			printSquare();
			return;
		}

		System.out.println("Please enter columns");
		int columns = scanner.nextInt();

		if (rows != columns) {
			System.out.println("Please enter equal number of rows and columns");
			System.out.println();
			printSquare();
			return;
		}

		for (int row = 0; row < rows; row++) {
			System.out.println();
			for (int column = 0; column < columns; column++) {
				System.out.print("*");
			}
		}
	}


	private static void printRectangleEdges() {
		System.out.println("Please enter a number: ");
		Scanner numberOfRows = new Scanner(System.in);
		if (numberOfRows.hasNextInt()) {
			int noOfRows = numberOfRows.nextInt();
			for (int row = 0; row < noOfRows; row++) {
				System.out.print("*");
			}
			System.out.println();
			for (int column = 0; column < noOfRows - 1; column++) {
				System.out.print("*");
				for (int space = 0; space < noOfRows - 2; space++) {
					System.out.print(" ");
				}
				System.out.print("*");
				System.out.println();
			}
			for (int row = 0; row < noOfRows; row++) {
				System.out.print("*");
			}
			System.out.println();
		} else {
			printRectangleEdges();
		}
	}

}

